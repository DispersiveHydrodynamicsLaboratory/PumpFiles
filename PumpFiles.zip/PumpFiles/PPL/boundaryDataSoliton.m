% This script generates an array of boundary data for use with Syringe Pump

maxphases = 339;% max is 340;
alpha = 0.25; % min^(1/4)*cm^(1/4)
Q0 = 0.1; % Base pump rate (ml/min)
A0 = pi*(0.5*(alpha*Q0^0.25))^2; % Base conduit area (cm^2)
epsilon = 0.0109;
L0 = sqrt(A0/(8*pi*epsilon)); % Vertical length scale (cm)
U0 = Q0/(60*A0); % (cm/s)
T0 = L0/U0;

% Function definition
% Generate soliton
A1 = 10;
c = (2*A1^2*log(A1)-A1^2+1)/(A1^2-2*A1+1);
z0 = -10;
fun = @(s) z0./(z0-2*s); % BC at z = 0 (nozzle)
tmin = 0;
tmax = -2*z0/c;
dt = 0.2/T0;
t = [tmin:dt:tmax];

disp(['Soliton speed = ',num2str(c*U0),' cm/s']);


% Minimum delta t is 0.l s

% Compute Q and adjust for values too small
xi = -c*t-z0;
% Compute from zero forward and use even reflection
[foo,ind] = min(abs(xi));
if xi(ind) < 0
    ind = ind - 1;
end
A = zeros(size(t));
A(1:ind) = fliplr(get_soli(xi(ind:-1:1),A1,2,1e-4) - 1);
A(ind+1:end) = get_soli(-xi(ind+1:end),A1,2,1e-4) - 1;
D = 2*sqrt(A*A0/pi); % Dimensional conduit diameter
Q = (D/alpha).^4; % Dimensional flux (ml/min)
Qnew = 0;%Q(1);
ctr = 1;
tnew = t(1);
for ii=1:length(Q)
    if abs(Q(ii)-Qnew(ctr)) >= 0.003
        ctr = ctr + 1;
        Qnew(ctr) = Q(ii);
        tnew(ctr) = t(ii);
    end
end



% if (tmax-tmin)/dt > maxphases/2
%     dt = (tmax-tmin)/(maxphases/2-1);
%     % Round up to the nearest tenth of second
%     dt = ceil(dt*T0*10)/(T0*10);
% end
% disp(['dt = ',num2str(dt*T0),' s']);
disp(['tmin = ',num2str(tmin*T0),' s']);
disp(['tmax = ',num2str(tmax*T0),' s = ',num2str(tmax*T0/60),' min']);

% Plot Q and A
figure(1)
clf()
subplot(2,1,1);
plot(t,A);
xlabel('t');
ylabel('A');

subplot(2,1,2);
plot(t*T0/60,Q,'r--',...
     tnew*T0/60,Qnew,'b-');
xlabel('t (min)');
ylabel('Q (ml/min)');

% Save data
data = zeros(length(Qnew)*2-1,1);
data(1:2:end) = Qnew;
data(2:2:end) = Qnew(2:end);

dtnew = tnew(2:end) - tnew(1:end-1);
mins = floor(dtnew*T0/60);
secs = floor(dtnew*T0-60*mins);
tenths = floor(10*(dtnew*T0-secs-60*mins));
hrssecs = zeros(length(data),1);
minstenths = zeros(length(data),1);
hrssecs(2:2:end) = secs;
minstenths(1:2:end-1) = mins;
minstenths(2:2:end) = tenths;

disp(['Number of phases = ',int2str(length(data))]);
disp(['Max dt = ',num2str(max(dtnew*T0)),' s']);
disp(['Min dt = ',num2str(min(dtnew*T0)),' s']);
save('boundaryData.txt','data','-ascii');
save('hrssecs.txt','hrssecs','-ascii');
save('minstenths.txt','minstenths','-ascii');