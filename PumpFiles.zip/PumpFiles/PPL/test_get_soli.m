A = 3;
n = 2;
tol = 1e-7;
xi = [0:5e-2:20];
% Compare with Mathematica result for large u close to 1
ximax = soli_integral(1+1e-11,3,2,tol);
xiexact = 49.00917318938026;
disp(['ximax          = ',num2str(ximax,15)]);
disp(['xiexact        = ',num2str(xiexact,15)]);
disp(['Rel Difference = ',num2str(abs(ximax-xiexact)/xiexact,15)]);
tic
u = get_soli(xi,A,n,tol);
toc

figure(1)
clf()
subplot(2,1,1)
plot([-fliplr(xi),xi],[fliplr(u),u],'k-');
xlabel('$\xi$','interpreter','latex');
ylabel('$u$','interpreter','latex');
axis tight;
title(['$n = ',num2str(n),', A = ',num2str(A),', tol = ',num2str(tol),'$'],...
	  'interpreter','latex');
subplot(2,1,2)
semilogy([-fliplr(xi),xi],[fliplr(u),u]-1,'k-');
axis tight;
xlabel('$\xi$','interpreter','latex');
ylabel('$u-1$','interpreter','latex');

