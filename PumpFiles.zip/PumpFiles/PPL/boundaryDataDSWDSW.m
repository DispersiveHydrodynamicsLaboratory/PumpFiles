% This script generates an array of boundary data for use with Syringe Pump

maxphases = 339;% max is 340;
alpha = 0.2639; % min^(1/4)*cm^(1/4)
Q0 = 0.05; % Base pump rate (ml/min)
D0 = 75.5*5/2363*1.036; % cm
A0 = pi*(0.5*(alpha*Q0^0.25))^2;%0.018585475;% % Base conduit area (cm^2)
alphaMeasured = 2*sqrt(A0/pi)/Q0^0.25;
epsilon = 0.0113;
L0 = sqrt(A0/(8*pi*epsilon)); % Vertical length scale (cm)
U0 = Q0/(60*A0); % (cm/s)
T0 = L0/U0;

% Function definition
% Ramp to discontinuity at z = z0
z0 = 40/L0;
ADSW1 = 3.5;  % Backflow:  > 8/3, implosion:  > 32/5
fun = @(s) z0./(z0-2*s); % BC at z = 0 (nozzle)
tmin = 0;
tmax = z0*(ADSW1-1)/(2*ADSW1);

disp(['z0 = ',num2str(z0)]);
disp(['A1 = ',num2str(ADSW1)]);
disp(['Breaking should occur at t = ',num2str(T0*z0/2),...
    ' s = ',num2str(T0*z0/120),' min']);

% Minimum delta t is 0.l s
dt = 0.3/T0;
t1 = [tmin:dt:tmax];

% Compute Q and adjust for values too small
A1 = fun(t1) - 1; % Subtract off background assumed to be provided by pump #2
D1 = 2*sqrt(A1*A0/pi); % Dimensional conduit diameter
Q1 = (D1/alpha).^4; % Dimensional flux (ml/min)

Qnew1 = Q1(1);
ctr = 1;
tnew1 = t1(1);
for ii=1:length(Q1)
    if abs(Q1(ii)-Qnew1(ctr)) >= 0.01
        ctr = ctr + 1;
        Qnew1(ctr) = Q1(ii);
        tnew1(ctr) = t1(ii);
    end
end

% Set delay between DSWs
t_delay = 150/T0;
t2 = [tmax+dt,tmax+dt+t_delay];
A2 = A1(end)*[1,1];
D2 = 2*sqrt(A2*A0/pi);
Q2 = (D2/alpha).^4;

Qnew2 = Q2;
tnew2 = t2;

% Second DSW
z0 = 50/L0;
ADSW2 = 8;  % Backflow:  > 8/3, implosion:  > 32/5
fun = @(s) z0./(z0/ADSW1-2*s); % BC at z = 0 (nozzle)
tmin = t2(end)+dt;
tmax = tmin+z0/2*(1/ADSW1-1/ADSW2);
t3 = [tmin:dt:tmax];
A3 = fun(t3-tmin)-1;
D3 = 2*sqrt(A3*A0/pi);
Q3 = (D3/alpha).^4;

Qnew3 = Q3(1);
ctr = 1;
tnew3 = t3(1);
for ii=1:length(Q3)
    if abs(Q3(ii)-Qnew3(ctr)) >= 0.01
        ctr = ctr + 1;
        Qnew3(ctr) = Q3(ii);
        tnew3(ctr) = t3(ii);
    end
end

% Put em all together
Q = [Q1,Q2,Q3];
t = [t1,t2,t3];
A = [A1,A2,A3];
Qnew = [Qnew1,Qnew2,Qnew3];
tnew = [tnew1,tnew2,tnew3];



disp(['tmax = ',num2str(t(end)*T0),' s = ',num2str(t(end)*T0/60),' min']);

% Plot Q and A
figure(1)
clf()
subplot(2,1,1);
plot(t,A);
xlabel('t');
ylabel('A');

subplot(2,1,2);
plot(t*T0/60,Q,'r--',...
     tnew*T0/60,Qnew,'b-');
xlabel('t (min)');
ylabel('Q (ml/min)');

% Save data
data = zeros(length(Qnew)*2-1,1);
data(1:2:end) = Qnew;
data(2:2:end) = Qnew(2:end);

dtnew = tnew(2:end) - tnew(1:end-1);
mins = floor(dtnew*T0/60);
secs = floor(dtnew*T0-60*mins);
tenths = floor(10*(dtnew*T0-secs-60*mins));
hrssecs = zeros(length(data),1);
minstenths = zeros(length(data),1);
hrssecs(2:2:end) = secs;
minstenths(1:2:end-1) = mins;
minstenths(2:2:end) = tenths;

disp(['Number of phases = ',int2str(length(data))]);
disp(['Max dt = ',num2str(max(dtnew*T0)),' s']);
disp(['Min dt = ',num2str(min(dtnew*T0)),' s']);
save('boundaryData.txt','data','-ascii');
save('hrssecs.txt','hrssecs','-ascii');
save('minstenths.txt','minstenths','-ascii');