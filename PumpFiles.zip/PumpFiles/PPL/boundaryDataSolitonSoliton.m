% This script generates an array of boundary data for use with Syringe Pump

maxphases = 339;% max is 340;
alpha = 0.2639; % min^(1/4)*cm^(1/4)
Q0 = 0.05; % Base pump rate (ml/min)
A0 = pi*(0.5*(alpha*Q0^0.25))^2; % Base conduit area (cm^2)
epsilon = 0.0113;
L0 = sqrt(A0/(8*pi*epsilon)); % Vertical length scale (cm)
U0 = Q0/(60*A0); % (cm/s)
T0 = L0/U0;

% Generate first soliton
A1 = 6;
c1 = (2*A1^2*log(A1)-A1^2+1)/(A1^2-2*A1+1);
z1 = -10;
fun = @(s) z1./(z1-2*s); % BC at z = 0 (nozzle)
tmin = 0;
tmax = -2*z1/c1;
dt = 0.2/T0;
t1 = [tmin:dt:tmax];

disp(['First soliton speed = ',num2str(c1*U0),' cm/s']);


% Minimum delta t is 0.l s

% Compute Q and adjust for values too small
xi1 = -c1*t1-z1;
% Compute from zero forward and use even reflection
[foo,ind] = min(abs(xi1));
if xi1(ind) < 0
    ind = ind - 1;
end
Asol1 = zeros(size(t1));
Asol1(1:ind) = fliplr(get_soli(xi1(ind:-1:1),A1,2,1e-4) - 1);
Asol1(ind+1:end) = get_soli(-xi1(ind+1:end),A1,2,1e-4) - 1;
D = 2*sqrt(Asol1*A0/pi); % Dimensional conduit diameter
Q1 = (D/alpha).^4; % Dimensional flux (ml/min)
Qnew1 = 0;%Q(1);
ctr = 1;
tnew1 = t1(1);
for ii=1:length(Q1)
    if abs(Q1(ii)-Qnew1(ctr)) >= 0.003
        ctr = ctr + 1;
        Qnew1(ctr) = Q1(ii);
        tnew1(ctr) = t1(ii);
    end
end

% Save data
data1 = zeros(length(Qnew1)*2-1,1);
data1(1:2:end) = Qnew1;
data1(2:2:end) = Qnew1(2:end);

dtnew1 = tnew1(2:end) - tnew1(1:end-1);
mins1 = floor(dtnew1*T0/60);
secs1 = floor(dtnew1*T0-60*mins1);
tenths1 = floor(10*(dtnew1*T0-secs1-60*mins1));
hrssecs1 = zeros(length(data1),1);
minstenths1 = zeros(length(data1),1);
hrssecs1(2:2:end) = secs1;
minstenths1(1:2:end-1) = mins1;
minstenths1(2:2:end) = tenths1;

% Generate second soliton
A2 = 9;
c2 = (2*A2^2*log(A2)-A2^2+1)/(A2^2-2*A2+1);
z2= -10;
fun = @(s) z2./(z2-2*s); % BC at z = 0 (nozzle)
tmin = 0;
tmax = -2*z2/c2;
dt = 0.2/T0;
t2 = [tmin:dt:tmax];

disp(['Second soliton speed = ',num2str(c2*U0),' cm/s']);


% Minimum delta t is 0.l s

% Compute Q and adjust for values too small
xi2 = -c2*t2-z2;
% Compute from zero forward and use even reflection
[foo,ind] = min(abs(xi2));
if xi2(ind) < 0
    ind = ind - 1;
end
Asol2 = zeros(size(t2));
Asol2(1:ind) = fliplr(get_soli(xi2(ind:-1:1),A2,2,1e-4) - 1);
Asol2(ind+1:end) = get_soli(-xi2(ind+1:end),A2,2,1e-4) - 1;
D = 2*sqrt(Asol2*A0/pi); % Dimensional conduit diameter
Q2 = (D/alpha).^4; % Dimensional flux (ml/min)
Qnew2 = 0;%Q(1);
ctr = 1;
tnew2 = t2(1);
for ii=1:length(Q2)
    if abs(Q2(ii)-Qnew2(ctr)) >= 0.003
        ctr = ctr + 1;
        Qnew2(ctr) = Q2(ii);
        tnew2(ctr) = t2(ii);
    end
end


disp(['tmin = ',num2str(tmin*T0),' s']);
disp(['tmax = ',num2str(tmax*T0),' s = ',num2str(tmax*T0/60),' min']);

Q = [Q1,Q2];
A = [Asol1,Asol2];
t = [t1,t2+t1(end)];
tnew = [tnew1,tnew2(2:end)+tnew1(end)];
Qnew = [Qnew1,Qnew2(2:end)];

% Plot Q and A
figure(1)
clf()
subplot(2,1,1);
plot(t,A);
xlabel('t');
ylabel('A');

subplot(2,1,2);
plot(t*T0/60,Q,'r--',...
     tnew*T0/60,Qnew,'b-');
xlabel('t (min)');
ylabel('Q (ml/min)');

% Save data
data2 = zeros(length(Qnew2)*2-1,1);
data2(1:2:end) = Qnew2;
data2(2:2:end) = Qnew2(2:end);

dtnew2 = tnew2(2:end) - tnew2(1:end-1);
mins2 = floor(dtnew2*T0/60);
secs2 = floor(dtnew2*T0-60*mins2);
tenths2 = floor(10*(dtnew2*T0-secs2-60*mins2));
hrssecs2 = zeros(length(data2),1);
minstenths2 = zeros(length(data2),1);
hrssecs2(2:2:end) = secs2;
minstenths2(1:2:end-1) = mins2;
minstenths2(2:2:end) = tenths2;

data = [data1;100;data2];
hrssecs = [hrssecs1;0;hrssecs2];
minstenths = [minstenths1;0;minstenths2];

disp(['Number of phases = ',int2str(length(data2))]);
disp(['Max dt = ',num2str(max(dtnew*T0)),' s']);
disp(['Min dt = ',num2str(min(dtnew*T0)),' s']);
save('boundaryData.txt','data','-ascii');
save('hrssecs.txt','hrssecs','-ascii');
save('minstenths.txt','minstenths','-ascii');