function cmpn=getCompactionRateDirichlet6ORD(phi,n,m,dz)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Nicholas Lowman		6th Order Finite Difference
% 01 February 2012
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This is a function code for Matlab designed to 
% take a function \phi and solve for u in the linear equation
% (\phi^m) u - (\phi^n u_z)_z) = -(\phi^n)_z
% which has form L(\phi)*u = f(\phi) where L is a 
% discretized elliptic operator.  This is a modification of an existing 4th
% order FD code to extend the result to 6th order.
%
% Here, we fix the boundary conditions for the function
% \phi at every time step by requiring that it be 
% constant at \phi(0) = 1 for z going to negative
% infinity and \phi(N+1) = \phi_0, s.t 0<\phi_0<1.  This
% sets the boundary conditions for u, which we will call the
% cmpn function, at cmpn(0)=cmpn(1)=cmpn(2)=cmpn(N-2)=cmpn(N-1)=cmpn(N+1)=0
% from the equation \phi_t = \phi^m u.
% One final note is that the solution output will
% be second order in space, ie O(dz^6), where dz is our grid spacing
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs - 
%     phi: array of porosity for a given time
%     n:  permeability exponent
%     m:  porosity exponent
%     dz:  spatial grid spacing
% Output -
%     cmpn - solution for u in the linear equation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Determine the length of the \phi array

numpoints = length(phi);  % ie {numpoints = N+1}

% Find the value of \phi^n and \phi^m (still have length numpoints)

perm = phi.^n;	% Permeability
por = phi.^m;	% Porosity

% Input the values of the supertridiagonal matrix A

% Above Above Superdiagonal

a = (1/(dz*dz))*((1/3600)*perm(1:end-9)-(1/400)*perm(2:end-8)+...
    (1/80)*perm(3:end-7)-(1/90)*perm(4:end-6)-(1/80)*perm(5:end-5)+...
    (1/400)*perm(6:end-4)-(1/3600)*perm(7:end-3));

% Above Superdiagonal

b = (1/(dz*dz))*((-1/400)*perm(1:end-8)+(9/400)*perm(2:end-7)-...
    (9/80)*perm(3:end-6)+(3/20)*perm(4:end-5)+(9/80)*perm(5:end-4)-...
    (9/400)*perm(6:end-3)+(1/400)*perm(7:end-2));

% Superdiagonal

c = (1/(dz*dz))*((1/80)*perm(1:end-7)-(9/80)*perm(2:end-6)+...
    (9/16)*perm(3:end-5)-(3/2)*perm(4:end-4)-(9/16)*perm(5:end-3)+...
    (9/80)*perm(6:end-2)-(1/80)*perm(7:end-1));

% Diagonal

d = (49/(18*dz*dz))*perm(4:end-3) + por(4:end-3);    

% Subdiagonal

e = (1/(dz*dz))*(-(1/80)*perm(2:end-6)+(9/80)*perm(3:end-5)-...
    (9/16)*perm(4:end-4)-(3/2)*perm(5:end-3)+(9/16)*perm(6:end-2)-...
    (9/80)*perm(7:end-1)+(1/80)*perm(8:end));

% Below Subdiagonal

f = (1/(dz*dz))*((1/400)*perm(3:end-6)-(9/400)*perm(4:end-5)+...
    (9/80)*perm(5:end-4)+(3/20)*perm(6:end-3)-(9/80)*perm(7:end-2)+...
    (9/400)*perm(8:end-1)-(1/400)*perm(9:end));

% Below Below Subdiagonal

g = (1/(dz*dz))*(-(1/3600)*perm(4:end-6)+(1/400)*perm(5:end-5)-...
    (1/80)*perm(6:end-4)-(1/90)*perm(7:end-3)+(1/80)*perm(8:end-2)-...
    (1/400)*perm(9:end-1)+(1/3600)*perm(10:end));

% RHS

h = (1/dz)*((1/60)*perm(1:end-6)-(3/20)*perm(2:end-5)+...
    (3/4)*perm(3:end-4)-(3/4)*perm(5:end-2)+...
    (3/20)*perm(6:end-1)-(1/60)*perm(7:end));

h=h';

% Create the matrix A using the Matlab spdiags command which is
% significantly faster than using the diag command since matlab
% automatically takes advantage of the sparsity in its calculations

A = spdiags([[g';0;0;0] [f';0;0] [e';0] d' [0;c'] [0;0;b'] [0;0;0;a']], ...
    -3:3, numpoints-6, numpoints-6);

% Lastly, solve the system using Matlab's built-in solver and add in the bndry condns

cmpn = A\h;
cmpn = [0;0;0;cmpn(:);0;0;0];

% Return the output to the calling function

return;




