function [phi,z,t]=magma_initialstep6ORD(dz,zmin,zmax,k,tmax,phi0,n,m,filename)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Nicholas Lowman	6th Order Runge-Kutta
% 01 February 2012
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This is a Matlab function designed to solve the generalized
% 1-d magma equation.  This is an update on an existing code which performs
% the same operation, but here we generalize to a 6th order scheme and work 
% in conjunction with a 6th order finite difference solver.  The equation is 
%	\phi_t + (\phi^n - \phi^n(\phi_^{-m}\phi_t)_z)_z = 0
%	with dirichlet BCs	\phi(z,t) = { 1,		z -> -\inf
%									{ \phi_0<1, z->\inf
% This particular script will simulate the case of an 
% initial smoothed step function
%	\phi_0(z) = 1 + (1/2)(\phi_0-1)(tanh((z-z_0) / (\lambda+1))
%   which we have centered about z=0
% This script calls on the function getCompactionRateDirichlet4ORD
% at each time step, which solves the linear system
%	(\phi^m - dz(\phi^n dz))cmpn = -(\phi^n)_z 
% for the function cmpn at 4th order.  
% We then feed the output into this function to solve the linear ODE 
%   \phi_t = \phi^m cmpn.
%
% Our method will be a sixth order in time Runge-Kutta method.  See 
% the paper (Luther, 1967) - An Explicit 6th-Order Runge-Kutta Formula for
% more details.
%
% Input Parameters
%	dz = spatial grid scale (z_i = z_0 + i*dz)
%	zmax = length of spatial domain
%	k = size of time steps (t_i = i*k)
%	tmax = final time
%	phi0 = z -> inf dirichlet boundary condn (must be < 1)
%	n = permeability power law exponent
%	m = porosity power law exponent
%   filename = string naming the workspace to append data
% Initialized step function
%	phi = initial smoothed step function (created in the function code)
%
% Outputs
%	phi = (numtimes) x (numgridpts) array of the porosity function at 
%		  every time step
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 6th order RK commented out because of bug.  It has been replaced by the
% classical RK4 until difficulties have been resolved.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Define the z vector as z=[-zmax;dz;zmax]
									
z = zmin:dz:zmax; 

% Define the t vector as t=[0:k:tmax]

t=0:k:tmax;
numtimes = length(t);

% save(filename,'t', 'z', '-append');

% preallocate space for the matrix of porosities

phi = zeros(numtimes,length(z));

% Create output grids so we don't store the entire porosity array

% z_post = z(1:(.1)*1/dz:end);
z_post = z(1:end);
t_post = [t(1:1/k:end-2/k) t(end-2/k+1:end)];

% save(filename, 't','z','t_post','z_post','-append');

phi_post = zeros(length(t_post),length(z_post));

% Build our initial smoothed step function for phi at time 0

lambda = 10*dz;		% Parameter we need for setting the width of the step

% Now create a smooth approximation to the step function such that 
% lim(phi) =	[ 1, if n -> -inf
%				[ phi0 for n-> inf
				
phi(1,:) = (1/2) * ((1+phi0) + (phi0-1)*tanh(z/(4*lambda)));

% % If we want a box initial condition with height phi0 propagating on a
% % background of 1 with width w
% 
% w = 50;
% phi(1,:) = 1+(phi0/2)*(tanh((z+w)/(4*lambda))-tanh(z/(4*lambda)));

% phi_post(1,:) = phi(1,1:(.1)*1/dz:end); disp(1);
phi_post(1,:) = phi(1,:); disp(1);

% set up the 4-stage runge-kutta algorithm as follows

for i=1:numtimes-1
    
	% call to the function for u 
	cmpn1 = getCompactionRateDirichlet6ORD(phi(i,:),n,m,dz);
    	
	% find the value for k1
    calc = (phi(i,:).^m)';	% Need to work in col vecs not row recs
	k1 = k*calc.*cmpn1;
	
	% find an initial value for an intermediate problem using Euler's method
	phi_star = phi(i,:) + (1/2)*transpose(k1);
	
	% Call to the function for u to get an intermediate value and then calculate rhs
	cmpn2 = getCompactionRateDirichlet6ORD(phi_star,n,m,dz);
    calc = (phi_star.^m)';
	k2 = k*calc.*cmpn2;
    
    % Repeat twice more according the the RK4 method
    
	phi_star = phi(i,:) + (1/2)*transpose(k2);
	
	cmpn3 = getCompactionRateDirichlet6ORD(phi_star,n,m,dz);
    calc = (phi_star.^m)';
	k3 = k*calc.*cmpn3;   
    
    phi_star = phi(i,:) + transpose(k3);
	
	cmpn4 = getCompactionRateDirichlet6ORD(phi_star,n,m,dz);
    calc = (phi_star.^m)';
	k4 = k*calc.*cmpn4;   
	
	% Calculate and store the value for phi at the next time step
    calc = phi(i,:)';
    
	phi(i+1,:) = transpose(calc + (1/6)*(k1+2*k2+2*k3+k4));	% Need row vector

    % select the proper entries to save into our output grid
    A=find((t(i+1)-t_post)==0,1);
    if isempty(A)==0
        % phi_post(A,:) = phi(i+1,1:(0.1)*1/dz:end);
		phi_post(A,:) = phi(i+1,:);
        disp(i+1);
    end
				
	% Every 50 time steps, save the value of phi to the designated workspace
% 	integertest = mod((i-1)/50,1);
% 	if integertest==0
% %		save(filename,'phi', '-append');
%         disp(i);	% For displaying progress of the solver
%                     % Comment out if desired        
% 	end	
end	

% Save the final matrix phi one last time

% save(filename,'phi_post', '-append');

return;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% % Define the z vector as z=[-zmax;dz;zmax]
% 									
% z = -zmax:dz:zmax; 
% 
% % Define the t vector as t=[0:k:tmax]
% 
% t=0:k:tmax;
% numtimes = length(t);
% 
% save(filename,'t', 'z', '-append');
% 
% % Build our initial smoothed step function for phi at time 0
% 
% lambda = 4*dz;		% Parameter we need for setting the width of the step
% 
% % Now create a smooth approximation to the step function such that 
% % lim(phi) =	[ 1, if n -> -inf
% %				[ phi0 for n-> inf
% 				
% phi(1,:) = (1/2) * ((1+phi0) + (phi0-1)*tanh(z/(2*lambda)));
% 
% % set up the 6-stage runge-kutta algorithm as follows
% 
% for i=1:numtimes-1
% 	
% 	% call to the function for u 
% 	cmpn1 = getCompactionRateDirichlet6ORD(phi(i,:),n,m,dz);
%     	
% 	% find the value for k1
%     calc = (phi(i,:).^m)';	% Need to work in col vecs not row recs
% 	k1 = k*calc.*cmpn1;
% 	
% 	% find an initial value for an intermediate problem using Euler's method
% 	phi_star = phi(i,:) + k1';
% 	
% 	% Call to the function for u to get an intermediate value
% 	cmpn2 = getCompactionRateDirichlet6ORD(phi_star,n,m,dz);
%     calc = (phi_star.^m)';
% 	k2 = k*calc.*cmpn2;
%     
%     % Compute k3
%     
% 	phi_star = phi(i,:) + (1/8)*(3*k1'+k2');
% 	
% 	cmpn3 = getCompactionRateDirichlet6ORD(phi_star,n,m,dz);
%     calc = (phi_star.^m)';
% 	k3 = k*calc.*cmpn3;   
%     
%     % Compute k4
%     
%     phi_star = phi(i,:) + (1/27)*(8*k1'+2*k2'+8*k3');
% 	
% 	cmpn4 = getCompactionRateDirichlet6ORD(phi_star,n,m,dz);
%     calc = (phi_star.^m)';
% 	k4 = k*calc.*cmpn4;   
% 	
%     % Compute k5
%     
%     phi_star = phi(i,:) + (1/392)*(3*(3*(21)^(.5)-7)*k1'-8*(7-(21)^(.5))*k2'+...
%         48*(7-(21)^(.5))*k3'-3*(21-(21)^.5)*k4');
% 	
% 	cmpn5 = getCompactionRateDirichlet6ORD(phi_star,n,m,dz);
%     calc = (phi_star.^m)';
% 	k5 = k*calc.*cmpn5;   
%     
%     % Compute k6
%     
%     phi_star = phi(i,:) + 1/1960*(-5*(231+51*(21)^(.5))*k1'-40*(7+(21)^(.5))*k2'-...
%         320*(21^(.5))*k3'+3*(21+121*(21^(.5)))*k4'+392*(6+21^(.5))*k5');
% 	
% 	cmpn6 = getCompactionRateDirichlet6ORD(phi_star,n,m,dz);
%     calc = (phi_star.^m)';
% 	k6 = k*calc.*cmpn6; 
%     
%     % Compute k7
%     
%     phi_star = phi(i,:) + (1/180)*(15*(22+7*(21^(.5)))*k1'+120*k2'+40*(7*21^.5-5)*k3'-...
%         63*(3*21^.5-2)*k4'-14*(49+9*21^.5)*k5'+70*(7-21^.5)*k6');
%     
%     cmpn7 = getCompactionRateDirichlet6ORD(phi_star,n,m,dz);
%     calc = (phi_star.^m)';
% 	k7 = k*calc.*cmpn7; 
%     
% 	% Calculate and store the value for phi at the next time step
%     calc = phi(i,:)';
%     
% 	phi(i+1,:) = transpose(calc + (1/180)*...
%         (9*k1+64*k3+49*k5+49*k6+9*k7));	% Need row vector
% 
% 
% 				
% 	% Every 50 time steps, save the value of phi to the designated workspace
% 	integertest = mod((i-1)/50,1);
% 	if integertest==0
% 		save(filename,'phi', '-append');
%         disp(i);	% For displaying progress of the solver
%                     % Comment out if desired        
% 	end	
% end	
% 
% % Save the final matrix phi one last time
% 
% save(filename,'phi', '-append');
% 
% return;


