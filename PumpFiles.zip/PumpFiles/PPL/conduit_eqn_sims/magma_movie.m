% Script to generate movie 

fontsize = 16;

tmin_ind = 1;
tmax_ind = length(t_sol);
zmax_ind = length(z_sol);

phi_movie = phi_sol(tmin_ind:tmax_ind,1:5:zmax_ind);
z_movie = z_sol(1:5:zmax_ind);
t_movie = t_sol(tmin_ind:tmax_ind);

p = plot(z_movie,phi_movie(1,:),'linewidth',1.5);

set(gca,'fontsize',fontsize,'fontname','times');

maxsol = max(max(phi_sol));
axis([z_sol(1) z_sol(zmax_ind) 0.9 maxsol+maxsol/10]);
V = axis; hold off;

xlabel('$z$','interpreter','latex');
ylabel('$A(z,t)$','interpreter','latex');

title(['$t = $',num2str(t_movie(1))],'interpreter','latex'); drawnow;

disp('press <return> to begin'), pause

for i = 2:length(phi_movie(:,1))

    plot(z_movie,phi_movie(i,:),'linewidth',1.5); 

    xlabel('$z$','interpreter','latex');

    ylabel('$A(z,t)$','interpreter','latex');

    title(['$t = $',num2str(t_movie(i))],'interpreter','latex');

    axis(V);

    M(i-1) = getframe;

    drawnow; 

end