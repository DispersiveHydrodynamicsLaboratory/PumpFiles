function int=int_sol(u,A,m,n,tol)

% Here we set up the function for the solitary wave calculation.  It varies
% for each value of the parameters so we set cases based on this.  For
% values near the end points, we implement Taylor series approximations.

if (n+m)==2
    
    % We consider only integer values of m and n so for this to be true, we
    % must have m=0 and n=2.
    
    g = @(u,A,n) (2/(A^n - n*A + n - 1))*((A^n - (n - 1)*A*log(A) - A)*...
     u.^(3 - 2*n) + (A^n - n*A + n - 1)*u.^(4 - 2*n).*log(u) -...
     (A*log(A) - A + 1)*u.^(3 - n) - (A^n - n*A*log(A) - 1)*...
     u.^(4 - 2*n));
  
    % Some special function values
    gpA = (2*A^(2 - 2*n)*((-1 + A)*(-A + A^n)*n - A*(-1 + A^n)*...
        (-1 + n)*log(A)))/...
        (-1 + A^n + n - A*n);
    gppA = (2*A^(1 - 2*n)*(A^n*(A + 5*(-1 + A)*n - 3*(-1 + A)*n^2) +... 
        A*(-1 + (-1 + A)*n*(-7 + 4*n)) + A*(6 + 3*A^n*(-2 + n) -...
        4*n)*(-1 + n)*log(A)))/(-1 + A^n + n - A*n);
    gpp1 = (2*(A^n - (-1 + n)^2 + A*(-2 + n)*n - A*(-1 + n)*n*log(A)))/...
        (-1 + A^n + n - A*n);
    gppp1 = (-2*(-((-1 + n)^2*(-8 + 5*n)) + A^n*(-8 + 6*n) + A*n*...
        (15 + n*(-18 + 5*n)) -... 
        A*(-1 + n)*n*(-7 + 5*n)*log(A)))/(-1 + A^n + n - A*n);
    
    % Cutoffs for integration domains
    mu = max(0,sqrt(eps/(sqrt(2)*gpp1*tol))-(u-1));
    epsilon = sqrt(0.5*A*eps/(sqrt(-gpA*tol)));

    % Perform the integration over three different regions
    if u > A-epsilon % I3 only
     int = 2*sqrt(A-u)/sqrt(-gpA) - gppA*(A-u)^1.5/(6*(-gpA)^1.5);
    else
    int = 2*sqrt(epsilon)/sqrt(-gpA) - gppA*epsilon^1.5/(6*(-gpA)^1.5);
    if mu == 0 % I2 + I3
      int = int + quadl(@(w) 1./sqrt(g(w,A,n)),u,A-epsilon,tol);
    else % I1 + I2 + I3
      int = int + quadl(@(w) 1./sqrt(g(w,A,n)),u+mu,A-epsilon,tol);
      int = int + log((u+mu-1)/(u-1))/sqrt(0.5*gpp1) - ...
                  sqrt(2)*gppp1*mu/(6*gpp1^1.5);
    end
    end      
    
elseif m==1

      g = @(u,A,n) (2.*u.^(2-n).*(A+A.^n.*(-1+u)-u+u.^n-...
                  A.*u.^n+A.^n.*(-1+n-n.*u+u.^n).*log(A)-...
                  (-1+A.^n+n-A.*n).*u.^n.*log(u)))./...
            (-1+n+A.^n.*(-1+n).*(-1+n.*log(A)));
    % Some special function values 
    gpA = (2*A^(1 - n)*(-A - A^(2*n) + ...
                      A^n*(1 + A + (-1 + A)*(-1 + n)*n*log(A))))/...
        (-1 + n + A^n*(-1 + n)*(-1 + n*log(A)));
    gppA = (-6*A^(2*n) + 4*A*(-2 + n) - ...
          2*A^n*(-3 + n^2 - A*(4 + (-2 + n)*n) + ...
                 (3 + A*(-4 + n) - n)*(-1 + n)*n* ...
                 log(A)))/(A^n*(-1 + n)*(1 + A^n*(-1 + n*log(A))));
    gpp1 = (2*(-1 + A^n*(1 - 2*n) + 2*n + ...
             (-1 + A)*n^2 + A^n*(-1 + n)*n*log(A)))/...
         (-1 + n + A^n*(-1 + n)*(-1 + n*log(A)));
    gppp1 = (2*(-4 + 9*n + n^2*(-6 - A*(-3 + n) + n) + ...
              A^n*(4 + 3*(-3 + n)*n) - ...
              2*A^n*(-2 + n)*(-1 + n)*n*log(A)))/...
          (-1 + n + A^n*(-1 + n)*(-1 + n*log(A)));


    % Cutoffs for integration domains
    mu = max(0,sqrt(eps/(sqrt(2)*gpp1*tol))-(u-1));
    epsilon = sqrt(0.5*A*eps/(sqrt(-gpA*tol)));


    % Perform the integration over three different regions
    if u > A-epsilon % I3 only
     int = 2*sqrt(A-u)/sqrt(-gpA) - gppA*(A-u)^1.5/(6*(-gpA)^1.5);
    else
    int = 2*sqrt(epsilon)/sqrt(-gpA) - gppA*epsilon^1.5/(6*(-gpA)^1.5);
    if mu == 0 % I2 + I3
      int = int + quadl(@(w) 1./sqrt(g(w,A,n)),u,A-epsilon,tol);
    else % I1 + I2 + I3
      int = int + quadl(@(w) 1./sqrt(g(w,A,n)),u+mu,A-epsilon,tol);
      int = int + log((u+mu-1)/(u-1))/sqrt(0.5*gpp1) - ...
                  sqrt(2)*gppp1*mu/(6*gpp1^1.5);
    end
    end  
    
else

    % We consider only integer values of m and n.
    
    g = @(u,A,n,m) (2/((n + m - 2)*(n*A^(n + m - 1) - (n + m - 1)*A^n + m -... 
        1)))*(((n - 1)*A^(n + m - 1) - (n + m - 2)*A^n + (m - 1)*A)*...
     u.^(m - n + 1) - (n*A^(n + m - 1) - (n + m - 1)*A^n + m - 1)*...
     u.^(m - n + 2) +...
    (A^(n + m - 1) - (n + m - 1)*A + n + m - 2)*...
     u.^(m + 1) - (A^n - n*A + n - 1)*u.^(2*m));
  
    % Some special function values
    gpA = (2*A^(m - n)*(A^(m + n)*(A^n*(-1 + m) - A*n*(-2 + m + n) +...
        (-1 + n)*(-1 + m + n)) + A*(A*(-1 + m) + A^n*(-(n*(-2 + m + n)) +...
        A*(-1 + n)*(-1 + m + n)))))/((-2 + m + n)*(A - A*m + A^n*(-(A^m*n) +...
        A*(-1 + m + n))));
    gppA = (2*A^m*(-3*A^(-2 + m + n)*(-1 + m)*m + (2*(-1 + m)*...
        (-1 - m + n))/A^n + ((1 + 2*m - n)*n*(-2 + m + n))/A +...
        A^(-1 + m)*(1 + 3*m - n)*n*(-2 + m + n) - (2 + 2*m - n)*...
        (-1 + n)*(-1 + m + n) - A^(-2 + m)*(3*m - n)*(-1 + n)*...
        (-1 + m + n)))/((-2 + m + n)*(-1 + m + A^(-1 + m + n)*n -...
        A^n*(-1 + m + n)));
    gpp1 = (2*A^n*(-(A^m*(-1 + n)*n) + A*(-2 + m + n)*(-1 + m + n)) -... 
        2*A*(-1 + m)*(m + (-1 + A)*m*n + (-1 + n)*(2 + (-1 + A)*n)))/...
        ((-2 + m + n)*(A - A*m + A^n*(-(A^m*n) + A*(-1 + m + n))));
    gppp1 = (2*A*(-1 + m)*(4*m - n)*(-1 + n)*(-2 + m + n) -...
        2*A^2*(-1 + m)*(-1 + 4*m - n)*n*(-1 + m + n) - 4*A^(1 + n)*...
        (-2*m + n)*(-2 + m + n)*(-1 + m + n) + 2*A^(m + n)*(-1 + n)*...
        n*(-1 - 3*m + 2*n))/((-2 + m + n)*(A - A*m + A^n*(-(A^m*n) +...
        A*(-1 + m + n))));
    
    % Cutoffs for integration domains
    mu = max(0,sqrt(eps/(sqrt(2)*gpp1*tol))-(u-1));
    epsilon = sqrt(0.5*A*eps/(sqrt(-gpA*tol)));

    % Perform the integration over three different regions
    if u > A-epsilon % I3 only
     int = 2*sqrt(A-u)/sqrt(-gpA) - gppA*(A-u)^1.5/(6*(-gpA)^1.5);
    else
    int = 2*sqrt(epsilon)/sqrt(-gpA) - gppA*epsilon^1.5/(6*(-gpA)^1.5);
    if mu == 0 % I2 + I3
      int = int + quadl(@(w) 1./sqrt(g(w,A,n,m)),u,A-epsilon,tol);
    else % I1 + I2 + I3
      int = int + quadl(@(w) 1./sqrt(g(w,A,n,m)),u+mu,A-epsilon,tol);
      int = int + log((u+mu-1)/(u-1))/sqrt(0.5*gpp1) - ...
                  sqrt(2)*gppp1*mu/(6*gpp1^1.5);
    end
    end
    
end









% % yp=n+m*sin(z)-a*sqrt(y);    (This works with the sample code in test.m)
% 
% if (n+m)==2
%     denom = a^n-n*log(a)+n-1;
%     A = (a^n-(n-1)*a*log(a)-a)*y.^(3-2*n);
%     B = (a^n-n*a+n-1)*y.^(4-2*n).*log(y);
%     C = (a*log(a)-a+1)*y.^(3-n);
%     D = (a^n-n*a*log(a)-1)*y.^(4-2*n);
%     numer = 2*(A+B-C-D);
%     
%     g= numer./denom;
%     
%     yp = -1./sqrt(abs(g));
% 
% elseif m==1
%     denom = (n-1)*(n*a^n*log(a) - a^n +1);
%     A = ((n-1)*a^n*log(a)-a^n+a)*y.^(2-n);
%     B = (n*a^n*log(a) - a^n + 1)*y.^(3-n);
%     C = (a^n-n*a+n-1)*y.^2.*log(y);
%     D = (a^n*log(a)-a+1)*y.^2;
%     numer = 2*(A-B-C+D);
%     
%     g = numer./denom;
%     
%     yp = -1./sqrt(abs(g));
%     
% else
%     denom = (n+m-2)*(n*a^(n+m-1)-(n+m-1)*a^n+m-1);
%     A = ((n-1)*a^(n+m-1)-(n+m-2)*a^n+(m-1)*a)*y.^(m-n+1);
%     B = (n*a^(n+m-1)-(n+m-1)*a^n+m-1)*y.^(m-n+2);
%     C = (a^(n+m-1)-(n+m-1)*a+n+m-2)*y.^(m+1);
%     D = (a^n-n*a+n-1)*y.^(2*m);
%     numer = 2*(A-B+C-D);
%     
%     g = numer./denom;
%     
%     yp = -1./sqrt(abs(g));
%     
% 
% end



