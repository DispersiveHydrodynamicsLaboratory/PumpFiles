function u = getSolitaryV2( z,z0,a,m,n )
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Nicholas Lowman
% 31 October 2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This is a Matlab function designed to create an analytic solitary wave
% from the generalized magma equation.  This script works in
% conjuction with the driver code solitary_plot.m to set the initial
% solitary wave, which we then integrate forward in time.  From the
% literature, we have an implicit representation of the solitary wave.
%
% Inputs:
%   z = spatial domain
%   z0 = location of the peak of the solitary wave
%   a = 1 + amplitude of the solitary wave
% Output:
%   phi = row vector representing the solitary wave
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tol = 1e-7;

% Set the background porosity to 1 for the right half of the solwave
% uR=ones(size(find(z>=z0)));

% Assign a length for uL
N=length(find(z<z0));

% Find the absolute distance from the peak to the point
zabs=z-z0;

% Set our tolerance level for minimum phi to find distance
ueps=1+1e-11;

% Set the largest domain for root finding
zeps=int_sol(ueps,a,m,n,tol);

if zeps>max(zabs)
    disp('Error. Spatial domain not large enough.');
elseif -zeps<min(zabs)
    disp('Error. Spatial domain not large enough.');
end

% Restrict root finding to regions with phi>phieps. This returns the
% indices of all points where zabs(i)<=zeps(i)
phibarR=find(zabs<=zeps & zabs>=0); 
uR = zeros(size(phibarR));

% % Find the zeros of zeta-zabs which will be the wave
% for i=phibar(1):phibar(end)
%     u(i)=fzero(@(phi) s(phi,a,m,n)-zabs(i),[ueps a]);
% end

for ii=phibarR(1):phibarR(end)
    % Assume xi is increasing so u is decreasing (use bisection)
    if ii > phibarR(1) 
     uR(ii+1-phibarR(1)) = fzero(@(z) int_sol(z,a,m,n,tol)-zabs(ii),[ueps,uR(ii-phibarR(1))],tol);
    else
     uR(1) = fzero(@(z) int_sol(z,a,m,n,tol) - zabs(ii),[ueps,a],tol);
    end
end

% Our domain is asymmetric, but we need to do an even reflection.

phibarL = find(abs(zabs)<zeps & zabs<0);

u=ones(size(z));
u(phibarR(1):phibarR(end)) = uR;
u(phibarL(1):phibarL(end))=fliplr(uR(2:end));

% u=[fliplr(uR(2:N+1)),uR];

return;
end







%zeta=@(f,A,m,n) quadgk(@(phi)solwave(phi,A,m,n),A,f);


% Set the background porosity to 1
% f=ones(size(z));
% 
% % Find the absolute distance from the peak to the point
% zabs=abs(z-z0);
% 
% % Set our tolerance level for minimum phi to find distance
% feps=1.0001;
% 
% % Set the largest domain for root finding
% zeps=abs(zeta(feps,a,m,n));
% 
% % Restrict root finding to regions with phi>phieps. This returns the
% % indices of all points where zabs(i)<=zeps(i)
% phibar=find(zabs<=zeps); 
% 
% % Find the zeros of zeta-zabs which will be the wave
% for i=phibar(1):phibar(end)
%     f(i)=fzero(@(phi) zeta(phi,a,m,n)-zabs(i),[feps a]);
% end
% 
% return;
% end
% 
% function res = zeta(f,A,m,n)
% 
% if f == A
%     res = 0;
%     return;
% end
% [res,errbnd] = quadgk(@(phi)solwave(phi,A,m,n),A,f,'MaxIntervalCount',12800); 
% res=real(res);
% if errbnd>1e-2
%     disp('quadgk may not have converged');
% end
% return;
% end