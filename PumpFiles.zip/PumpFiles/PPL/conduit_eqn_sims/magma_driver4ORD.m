%%% Magma_Driver4ORD %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Nicholas Lowman & Michelle Maiden
% 02 February 2012 & Updated 12 May 2015
%
% This is a driver script for computing the 4th order in space and time
% magma DSW for the porosity function.  It works in conjunction with a 4th
% order Runge-Kutta time stepping method for a linear ODE, which also calls
% on a 4th order finite difference method for inverting a linear elliptic
% operator.  The details of those programs are contained in their
% documentation.  This file saves the computed phi function and the
% associated workspace so that it can be called by post-processing scripts
% for plotting and checking values of conserved quantitites.
%
% Variable Assignments Required:
%     tmax - length of time to run the program
%     phi0 - limit of the phi function at +/infty (works with initial step)
%     n - value of the permeability exponent
%     m - value of the porosity exponent
%     dz - spatial grid spacing
%     zmax - total length of grid
%
% 
% Function Calls
%     magma_initialstep4ORD - computes the phi function
%
% Outputs
%     Saves the key variables of the workspace to a file in the folder
%     data. Naming of the file is based on the distinguishing variables.
%     (note that the program can also output the runtime)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% clear all
tic;
format shortE
% Set all parameter values
tmax = 1000;
phi0 = 0.6;
n=2;
m=1;
% dz = sqrt(phi0^n)/4;    % number of grid points per smallest compaction length
dz = .1;
zmin=-150;
zmax =600;

cour=1/(n);							% Courant number
% k=cour*dz/((1-phi0^n)/(1-phi0));	% CFL Condition

k = (cour/2)*dz;

% Name the workspace we create and save the important variables
id=sprintf('t%dm%dn%dphi%d',tmax, m, n, 100*phi0);
filename=sprintf('./data/%s',id);

% save(filename);

% Find the phi function

% [phi,z,t] = magma_initialstep4ORD(dz,zmin,zmax,k,tmax,phi0,n,m,filename);
[phi_sol,z_sol,t_sol] = magma_initialstep4ORD_rareIC(dz,zmin,zmax,k,tmax,phi0,n,m,filename);
toc;

% % Script to generate movie 
% 
% fontsize = 16;
% 
% tmin_ind = 1000;
% tmax_ind = length(t_sol);
% zmax_ind = length(z_sol)
% 
% phi_movie = phi_sol(tmin_ind:50:tmax_ind,1:5:18000);
% z_movie = z_sol(1:5:zmax_ind);
% t_movie = t_sol(tmin_ind:50:tmax_ind);
% 
% p = plot(z_movie,phi_movie(1,:),'linewidth',1.5);
% 
% set(gca,'fontsize',fontsize,'fontname','times');
% 
% maxsol = max(max(phi_sol));
% axis([z_sol(1) z_sol(zmax_ind) 0.9 maxsol+maxsol/10]);
% V = axis; hold off;
% 
% xlabel('$z$','interpreter','latex');
% ylabel('$A(z,t)$','interpreter','latex');
% 
% title(['$t = $',num2str(t_movie(1))],'interpreter','latex'); drawnow;
% 
% disp('press <return> to begin'), pause
% 
% for i = 2:length(phi_movie(:,1))
% 
%     plot(z_movie,phi_movie(i,:),'linewidth',1.5); 
% 
%     xlabel('$z$','interpreter','latex');
% 
%     ylabel('$A(z,t)$','interpreter','latex');
% 
%     title(['$t = $',num2str(t_movie(i))],'interpreter','latex');
% 
%     axis(V);
% 
%     M(i-1) = getframe;
% 
%     drawnow; 
% 
% end

% check leading edge speed

for i = length(t_sol)-10/k:length(t_sol)
    ind = find(phi_sol(i,:)==max(phi_sol(i,:)),1,'first');
    z_max(i-length(t_sol)+10/k+1) = z_sol(ind);
    t_max(i-length(t_sol)+10/k+1) = t_sol(i);
end
p = polyfit(t_max,z_max,1);
s_plus = p(1)