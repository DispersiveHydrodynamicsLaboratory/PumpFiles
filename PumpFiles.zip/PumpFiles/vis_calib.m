
% Created by : Jordan Stern & Dalton Anderson
% Last edited: 6/24/2015
% This function accepts an array of measured viscosity values and outputs
% an array of adjusted viscosity values that account for the calbration 
% error of the viscometer. 


function [mu_actual] = vis_calib( mu_observed )

% ----- Standard Fluids -----
% [temperature (C) , Viscosity (cP)]
% 
% N15000 =[   20,     64880;
%             25,     40620;
%             40,     11370;
%             50,     5378;
%             60,     2725;
%             80,     840.5;
%             100,    318.3];
% 
% N4000 = [   20, 	14330;
%             25,     9469;
%             40,     3056;
%             50,     1575;
%             60,     862.3;
%             80,     304.4;
%             100,    128.6];
%         
% N100 =  [   20,     288.3;
%             25,     205.3;
%             37.78,	95.34;
%             40,      84.58;
%             50,      51.37;
%             80, 	16.05;
%             98.89,	9.31;
%             100,   	9.05];
%         
% N10  =  [   20,     18.42;
%             25, 	14.79;
%             37.78,	9.055;
%             40, 	8.391;
%             50,   	6.132;
%             80, 	2.943;
%             98.89, 	2.069;
%             100,	2.031];
        
% Find Actual Vis. at intermedeate temps    
        
muo = mu_observed;

% Viscometer calibration data (in cP):

mu_calibration_measured = [17.7 , 29.7 , 74.9 , 114.3 , 227.8 , 2340 , 12275 , 57228]; 
% Measured values for viscosities of standard fluids^ 
mu_calibration_actual = [16.5 , 29.9 , 84.6 , 123.6 , 243.0 , 2134 , 11957, 53930]; 
% Actual values for viscosities of standard fluids^


mua = zeros(size(muo)); % Intialize array to store corrected values
i=1;

% For each measured viscosity value in the array, muo(i), find the actual
% viscosity value, mua(i), by linear interpolation or extrapolation 
% of the above calibration data.
while (i <= length(muo))
    if muo(i)<mu_calibration_measured(2)
        mua(i) = interp1(mu_calibration_measured(1:2),...
        mu_calibration_actual(1:2),muo(i),'linear','extrap'); % in cP
    
    elseif muo(i)<mu_calibration_measured(3) && muo(i) >= mu_calibration_measured(2)
        mua(i) = interp1(mu_calibration_measured(2:3),...
        mu_calibration_actual(2:3),muo(i),'linear','extrap');
    
    else
        mua(i) = interp1(mu_calibration_measured(3:4),...
        mu_calibration_actual(3:4),muo(i),'linear','extrap');
    end
    
    i=i+1;
end
mu_actual = mua;
end